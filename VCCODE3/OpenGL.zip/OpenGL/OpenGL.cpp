// OpenGL.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"

#define MAX_LOADSTRING 100
#define M_PI 3.14
#define   FLOATEQUAL(d1,d2,width)   (d1>=d2 - width && d1 <= d2 +width) 

#include <GL/gl.h>
#include <GL/glu.h>
#include <math.h>

#pragma comment( lib, "opengl32.lib" )
#pragma comment( lib, "glu32.lib" )

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text

// ȫ�ֱ�����
HWND g_hWnd;
HDC g_hDC;
HGLRC g_glRes;
bool g_bStartSwap=false;


// �˴���ģ���а����ĺ�����ǰ��������
void OnCreate( HWND hWnd );
void OnCreated( void );
void OnDestroy( void );
void OnDraw( void );
void SetProjMatrix( WORD wWidth, WORD wHeight );
void SetModalMatrix( void );
void OnIdle( void );


// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_OPENGL, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_OPENGL);

	// Main message loop:
	// ����Ϣѭ����
    while ( true )
    {
        if ( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
        {
            if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
            continue;
        }
        if ( WM_QUIT == msg.message )
        {
            break;
        }
        OnIdle();
    }


	return msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= 0;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_OPENGL);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_OPENGL;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   OnCreated();


   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    switch (message) 
    {
    case WM_CREATE:
        OnCreate( hWnd );
        break;
    case WM_KEYDOWN:
        g_bStartSwap = !g_bStartSwap;
        break;
    case WM_MOVE:
        SetWindowText( g_hWnd, "Move" );
        break;
    case WM_COMMAND:
        wmId = LOWORD(wParam); 
        wmEvent = HIWORD(wParam); 
        // �����˵�ѡ��
        switch (wmId)
        {
        case IDM_ABOUT:
            DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
            break;
        case IDM_EXIT:
            DestroyWindow(hWnd);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
        break;
		case WM_SIZE:
			SetProjMatrix( LOWORD( lParam ), HIWORD( lParam ) );
			break;
		case WM_DESTROY:
			OnDestroy();
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}


// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}

void OnCreate( HWND hWnd )
{
    g_hWnd = hWnd;
}

void OnDestroy( void )
{
    ReleaseDC( g_hWnd, g_hDC );
    wglDeleteContext( g_glRes );
}

void OnCreated( void )
{
    g_hDC = GetDC( g_hWnd );

    PIXELFORMATDESCRIPTOR pfd;
    ZeroMemory( &pfd, sizeof(PIXELFORMATDESCRIPTOR) );
    pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR );
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 24;
    pfd.cDepthBits = 32;

    SetPixelFormat( g_hDC, ChoosePixelFormat( g_hDC, &pfd ), &pfd );

    g_glRes = wglCreateContext( g_hDC );
    wglMakeCurrent( g_hDC, g_glRes );

    glEnable( GL_CULL_FACE );
    glCullFace( GL_BACK );

    glEnable( GL_DEPTH_TEST );
    glDepthFunc( GL_LEQUAL );

    int LightPos[] = { 50, 50, 10, 1 };
    float LightColor[] = { 0.3f, 0.3f, 0.3f, 1.0f };

    glEnable(GL_LIGHTING);
    glLightiv( GL_LIGHT0, GL_POSITION, LightPos );
    glLightfv( GL_LIGHT0, GL_AMBIENT, LightColor );
    glLightfv( GL_LIGHT0, GL_DIFFUSE, LightColor );
    glEnable( GL_LIGHT0 );
    glEnable( GL_COLOR_MATERIAL );
    glColorMaterial( GL_FRONT, GL_AMBIENT_AND_DIFFUSE );

    glShadeModel( GL_SMOOTH );

    glClearColor( 255.0f / 255.0f, 255.0f / 255.0f, 200.0f / 255.0f, 0.0 );
	

    glColor3ub( 140, 200, 255 );
}

void OnDraw( void )
{
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glBegin( GL_QUADS ); // ���û���ģʽ�����ǻ�һ��ƽ����ı���
	glVertex2i( 5, 5 );
	glVertex2i( -5, 5 );
	glVertex2i( -5, -5 );
	glVertex2i( 5, -5 );
	glEnd();
    SwapBuffers( g_hDC );
}

void SetModalMatrix( void )
{
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity( );
    static float fRadius = 0;
    fRadius += 0.01f;
    if ( fRadius > M_PI * 2 )
    {
        fRadius = 0;
    }
	int r=1;
    gluLookAt( cosf( fRadius ) * r, sinf( fRadius ) * r, 15.0,
        0.0, 0.0, 0.0,
        0.0, 0.0, 1.0 );
}

void SetProjMatrix( WORD wWidth, WORD wHeight )
{
    glViewport( 0, 0, wWidth, wHeight );
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity( );
    gluPerspective( 45.0, (double)wWidth / (double)wHeight, 1.0, 1000.0 );
}

void OnIdle( void )
{
    SetModalMatrix();
    OnDraw();
}

