#include "TCPClient.h"

#pragma comment(lib,"WS2_32")


CTCPClient::CTCPClient(void)
{
	int error=WSAStartup(MAKEWORD(2,2),&m_wsaData);

	if(error!=0)
	{
		return;
	}

	if(LOBYTE(m_wsaData.wVersion)!=2 || HIBYTE(m_wsaData.wVersion)!=2)
	{
		WSACleanup();
		return;
	}

	m_socket=socket(AF_INET,SOCK_STREAM,0);

	m_sockSend.sin_addr.S_un.S_addr=inet_addr("192.168.5.13");
	m_sockSend.sin_port=htons(9999);
	m_sockSend.sin_family=AF_INET;

	connect( m_socket, ( struct sockaddr * ) & m_sockSend, sizeof( struct sockaddr ));
}

CTCPClient::~CTCPClient(void)
{
	closesocket(m_socket);

	WSACleanup();
}

int CTCPClient::SendData(BYTE *buff,int nLen)
{
	int lenword=0;
	lenword=send( m_socket, (char *)buff, nLen, 0 ) ;
	return lenword;
}
