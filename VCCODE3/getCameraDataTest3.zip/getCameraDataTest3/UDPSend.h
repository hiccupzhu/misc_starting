#pragma once
#include <winsock2.h>

class CUDPSend
{
public:
	CUDPSend(void);
	~CUDPSend(void);

	int SendData(BYTE *buff,int nLen);
public:
	WSADATA m_wsaData;
	SOCKET m_socket;
	SOCKADDR_IN m_sockSend;
};
