#pragma once

#include "avformat.h"
#include "swscale.h"
#include "avutil.h"
#include "flv.h"

// int64_t my_rescale_rnd(int64_t a, int64_t b, int64_t c, enum AVRounding rnd);
// int64_t my_rescale_q(int64_t a, AVRational bq, AVRational cq);
// int64_t my_rescale(int64_t a, int64_t b, int64_t c);
// static void compute_frame_duration(int *pnum, int *pden, AVStream *st,
// 								   AVCodecParserContext *pc, AVPacket *pkt);
// static int my_interleave_packet(AVFormatContext *s, AVPacket *out, AVPacket *in, int flush);
// static int compute_pkt_fields2(AVFormatContext *s, AVStream *st, AVPacket *pkt);
// int my_interleaved_write_frame(AVFormatContext *s, AVPacket *pkt);




