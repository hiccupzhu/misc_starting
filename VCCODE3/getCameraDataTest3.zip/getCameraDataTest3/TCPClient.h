#pragma once
#include <winsock2.h>

class CTCPClient
{
public:
	CTCPClient(void);
	~CTCPClient(void);

public:
	int SendData(BYTE *buff,int nLen);

	WSADATA m_wsaData;
	SOCKET m_socket;
	SOCKADDR_IN m_sockSend;

};
