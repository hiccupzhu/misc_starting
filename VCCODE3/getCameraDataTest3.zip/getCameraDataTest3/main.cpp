#include "..\getCameraData\Interface.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "stdint.h"
//#include "UDPSend.h"
#include "TCPClient.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#include "avformat.h"
#include "swscale.h"
#include "flv.h"


#pragma comment(lib,"lib/avcodec")
#pragma comment(lib,"lib/avformat")
//#pragma comment(lib,"lib/avfilter")
#pragma comment(lib,"lib/avutil")
//#pragma comment(lib,"lib/swscale")

#undef exit //

/* 5 seconds stream duration */
#define STREAM_DURATION   5.0
#define STREAM_FRAME_RATE 25 /* 25 images/s */
#define STREAM_NB_FRAMES  ((int)(STREAM_DURATION * STREAM_FRAME_RATE))
#define STREAM_PIX_FMT PIX_FMT_YUV420P /* default pix_fmt */

static int sws_flags = SWS_BICUBIC;//SWS_BICUBIC?

typedef struct FLVContext {
	int reserved;
	int64_t duration_offset;
	int64_t filesize_offset;
	int64_t duration;
	int delay; ///< first dts delay for AVC
	int64_t last_video_ts;
} FLVContext;

enum AVMediaType {
	AVMEDIA_TYPE_UNKNOWN = -1,
	AVMEDIA_TYPE_VIDEO,
	AVMEDIA_TYPE_AUDIO,
	AVMEDIA_TYPE_DATA,
	AVMEDIA_TYPE_SUBTITLE,
	AVMEDIA_TYPE_ATTACHMENT,
	AVMEDIA_TYPE_NB
};

/**************************************************************/
/* video output */

AVFrame *picture, *tmp_picture;
uint8_t *video_outbuf;
int frame_count, video_outbuf_size;
unsigned long lTime=0;

typedef struct
{
	uint8_t * data;
	int nCurrentposite;
}DATA;

DATA *pb=NULL;
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//#define MY_DEBUG

#ifdef MY_DEBUG
FILE *fp=NULL;
#else
CTCPClient sender;
#endif


/* add a video output stream */
static AVStream *add_video_stream(AVFormatContext *oc, enum CodecID codec_id)
{
    AVCodecContext *c;
    AVStream *st;


    st = av_new_stream(oc, 0);
    if (!st) {
        fprintf(stderr, "Could not alloc stream\n");
        exit(1);
    }

    c = st->codec;
    c->codec_id = codec_id;
    c->codec_type = CODEC_TYPE_VIDEO;

    /* put sample parameters */
    c->bit_rate = 400000;
    /* resolution must be a multiple of two */
    c->width = 320;
    c->height = 240;
    /* time base: this is the fundamental unit of time (in seconds) in terms
       of which frame timestamps are represented. for fixed-fps content,
       timebase should be 1/framerate and timestamp increments should be
       identically 1. */
    c->time_base.den = STREAM_FRAME_RATE;
    c->time_base.num = 1;
    c->gop_size = 12; /* emit one intra frame every twelve frames at most */
    c->pix_fmt = STREAM_PIX_FMT;
    if (c->codec_id == CODEC_ID_MPEG2VIDEO) {
        /* just for testing, we also add B frames */
        c->max_b_frames = 2;
    }
    if (c->codec_id == CODEC_ID_MPEG1VIDEO){
        /* Needed to avoid using macroblocks in which some coeffs overflow.
           This does not happen with normal video, it just happens here as
           the motion of the chroma plane does not match the luma plane. */
        c->mb_decision=2;
    }
    // some formats want stream headers to be separate
//     if(oc->oformat->flags & AVFMT_GLOBALHEADER)
//         c->flags |= CODEC_FLAG_GLOBAL_HEADER;

    return st;
}

static AVFrame *alloc_picture(int pix_fmt, int width, int height)
{
    AVFrame *picture;
    uint8_t *picture_buf;
    int size;

    picture = avcodec_alloc_frame();
    if (!picture)
        return NULL;
    size = avpicture_get_size((PixelFormat)pix_fmt, width, height);
    picture_buf =(uint8_t*) av_malloc(size);
    if (!picture_buf) {
        av_free(picture);
        return NULL;
    }
    avpicture_fill((AVPicture *)picture, picture_buf,
                   (PixelFormat)pix_fmt, width, height);
    return picture;
}

static void open_video(AVFormatContext *oc, AVStream *st)
{
    AVCodec *codec;
    AVCodecContext *c;

    c = st->codec;

    codec = avcodec_find_encoder(c->codec_id);
    if (!codec) {
        fprintf(stderr, "codec not found\n");
        exit(1);
    }

    /* open the codec */
    if (avcodec_open(c, codec) < 0) {
        fprintf(stderr, "could not open codec\n");
        exit(1);
    }

    video_outbuf = NULL;
    if (!(oc->oformat->flags & AVFMT_RAWPICTURE)) 
	{
        video_outbuf_size = 200000;
        video_outbuf = (uint8_t *) av_malloc(video_outbuf_size);
    }

    /* allocate the encoded raw picture */
    picture = alloc_picture(c->pix_fmt, c->width, c->height);
    if (!picture) {
        fprintf(stderr, "Could not allocate picture\n");
        exit(1);
    }

    tmp_picture = NULL;
    if (c->pix_fmt != PIX_FMT_YUV420P) {
        tmp_picture = alloc_picture(PIX_FMT_YUV420P, c->width, c->height);
        if (!tmp_picture) {
            fprintf(stderr, "Could not allocate temporary picture\n");
            exit(1);
        }
    }
}

void RGB2YUV420(uint8_t* RgbBuf,int nWidth,int nHeight,uint8_t* yuvBuf,unsigned long *len)
{

	int i, j; 
	unsigned char*bufY, *bufU, *bufV, *bufRGB,*bufYuv; 
	memset(yuvBuf,0,(unsigned int )*len);
	bufY = yuvBuf; 
	bufV = yuvBuf + nWidth * nHeight; 
	bufU = bufV + (nWidth * nHeight* 1/4); 
	*len = 0; 
	unsigned char y, u, v, r, g, b,testu,testv; 
	unsigned int ylen = nWidth * nHeight;
	unsigned int ulen = (nWidth * nHeight)/4;
	unsigned int vlen = (nWidth * nHeight)/4; 
	for (j = nHeight-1; j>=0;j--)
	{
		bufRGB = RgbBuf + nWidth * (nHeight - 1 - j) * 4 ; 
		for (i = 0;i<nWidth;i++)
		{
			int pos = nWidth * i + j;
			r = *(bufRGB++);
			g = *(bufRGB++);
			b = *(bufRGB++);
			bufRGB++;

			y = (unsigned char)( ( 66 * r + 129 * g + 25 * b + 128) >> 8) + 16 ;           
			u = (unsigned char)( ( -38 * r - 74 * g + 112 * b + 128) >> 8) + 128 ;           
			v = (unsigned char)( ( 112 * r - 94 * g - 18 * b + 128) >> 8) + 128 ;
			*(bufY++) = max( 0, min(y, 255 ));

			if (j%2 ==0)
			{
				if(i%2==0)
					*(bufV++) =max( 0, min(v, 255 ));
				else
					*(bufV++) =max( 0, min(u, 255 ));;	
			}

		}

	}
	*len = nWidth * nHeight+(nWidth * nHeight)/2;
} 

/* prepare a dummy image */
static void fill_yuv_image(AVFrame *pict, int frame_index, int width, int height,uint8_t* pRGB32)
{
	int x=0;
	int y=0;
	unsigned long lTemp=0;    
	uint8_t *pYUV=(uint8_t*)malloc(width*height*3/2);
	uint8_t *pYUVTemp=pYUV;		
	RGB2YUV420(pRGB32,width,height,pYUV,&lTemp);

	/* Y */
	for(y=0;y<height;y++) {
		for(x=0;x<width;x++) {
			pict->data[0][y * pict->linesize[0] + x] = *(pYUVTemp++);
		}
	}	

	/* Cb and Cr */
	for(y=0;y<height/2;y++) {
		for(x=0;x<width/2;x++) {
			pict->data[1][y * pict->linesize[1] + x] = *(pYUVTemp++);;
			pict->data[2][y * pict->linesize[2] + x] = *(pYUVTemp++);;
		}
	}

	free(pYUV);
}

static void put_amf_string(ByteIOContext *pb, const char *str)
{
	size_t len = strlen(str);
	put_be16(pb, len);
	put_buffer(pb, (unsigned char *)str, len);
}

int64_t av_dbl2int(double d){
	int e;
	if     ( !d) return 0;
	else if(d-d) return 0x7FF0000000000000LL + ((int64_t)(d<0)<<63) + (d!=d);
	d= frexp(d, &e);
	return (int64_t)(d<0)<<63 | (e+1022LL)<<52 | (int64_t)((fabs(d)-0.5)*(1LL<<53));
}

static void put_amf_double(ByteIOContext *pb, double d)
{
	put_byte(pb, AMF_DATA_TYPE_NUMBER);
	put_be64(pb, av_dbl2int(d));
}

static void put_amf_bool(ByteIOContext *pb, int b) 
{
	put_byte(pb, AMF_DATA_TYPE_BOOL);
	put_byte(pb, !!b);
}

static const uint8_t *my_ff_avc_find_startcode_internal(const uint8_t *p, const uint8_t *end)
{
	const uint8_t *a = p + 4 - ((intptr_t)p & 3);

	for (end -= 3; p < a && p < end; p++) {
		if (p[0] == 0 && p[1] == 0 && p[2] == 1)
			return p;
	}

	for (end -= 3; p < end; p += 4) {
		uint32_t x = *(const uint32_t*)p;
		//      if ((x - 0x01000100) & (~x) & 0x80008000) // little endian
		//      if ((x - 0x00010001) & (~x) & 0x00800080) // big endian
		if ((x - 0x01010101) & (~x) & 0x80808080) { // generic
			if (p[1] == 0) {
				if (p[0] == 0 && p[2] == 1)
					return p;
				if (p[2] == 0 && p[3] == 1)
					return p+1;
			}
			if (p[3] == 0) {
				if (p[2] == 0 && p[4] == 1)
					return p+2;
				if (p[4] == 0 && p[5] == 1)
					return p+3;
			}
		}
	}

	for (end += 3; p < end; p++) {
		if (p[0] == 0 && p[1] == 0 && p[2] == 1)
			return p;
	}

	return end + 3;
}

const uint8_t *my_ff_avc_find_startcode(const uint8_t *p, const uint8_t *end)
{
	const uint8_t *out= my_ff_avc_find_startcode_internal(p, end);
	if(p<out && out<end && !out[-1]) out--;
	return out;
}

int my_ff_avc_parse_nal_units(ByteIOContext *pb, const uint8_t *buf_in, int size)
{
	const uint8_t *p = buf_in;
	const uint8_t *end = p + size;
	const uint8_t *nal_start, *nal_end;

	size = 0;
	nal_start = my_ff_avc_find_startcode(p, end);
	while (nal_start < end) {
		while(!*(nal_start++));
		nal_end = my_ff_avc_find_startcode(nal_start, end);
		put_be32(pb, nal_end - nal_start);
		put_buffer(pb, nal_start, nal_end - nal_start);
		size += 4 + nal_end - nal_start;
		nal_start = nal_end;
	}
	return size;
}

int my_ff_avc_parse_nal_units_buf(const uint8_t *buf_in, uint8_t **buf, int *size)
{
	ByteIOContext *pb;
	int ret = url_open_dyn_buf(&pb);
	if(ret < 0)
		return ret;

	my_ff_avc_parse_nal_units(pb, buf_in, *size);

	av_freep(buf);
	*size = url_close_dyn_buf(pb, buf);
	return 0;
}

static av_always_inline av_const uint32_t my_bswap32(uint32_t ul)
{
	return ((ul & 0x000000FF) << 24) | ((ul & 0x0000FF00) << 8)  | ((ul & 0x00FF0000) >> 8) | ((ul & 0xFF000000) >> 24); 

}

typedef union my_alias {
	uint32_t u32;
	uint16_t u16[2];
	uint8_t  u8 [4];
	float    f32;
} my_alias32;

#define AV_RN(s, p) (((const my_alias##s*)(p))->u##s)
#define AV_RN32(p) AV_RN(32, p)
#define AV_RB(s, p)    my_bswap##s(AV_RN##s(p))

#define AV_RB24(x)                           \
	((((const uint8_t*)(x))[0] << 16) |         \
	(((const uint8_t*)(x))[1] <<  8) |         \
	((const uint8_t*)(x))[2])
#define AV_RB32(p)    AV_RB(32, p)



void my_put_byte(DATA *s, int b)
{
	*(s->data+s->nCurrentposite)=b;
	s->nCurrentposite++;
}

void my_put_buffer(DATA *s, const unsigned char *buf, int size)
{
	memcpy(s->data+s->nCurrentposite, buf, size);
	s->nCurrentposite += size;

}

void my_put_be32(DATA *s, unsigned int val)
{
	my_put_byte(s, val >> 24);
	my_put_byte(s, val >> 16);
	my_put_byte(s, val >> 8);
	my_put_byte(s, val);
}

void my_put_be16(DATA *s, unsigned int val)
{
	my_put_byte(s, val >> 8);
	my_put_byte(s, val);
}

void my_put_be24(DATA *s, unsigned int val)
{
	my_put_be16(s, val >> 8);
	my_put_byte(s, val);
}

void my_put_tag(DATA *s, const char *tag)
{
	while (*tag) {
		my_put_byte(s, *tag++);
	}
}

static void my_put_amf_string(DATA *s, const char *str)
{
	size_t len = strlen(str);
	my_put_be16(s, len);
	my_put_buffer(s, (unsigned char *)str, len);
}

void my_put_be64(DATA *s, uint64_t val)
{
	my_put_be32(s, (uint32_t)(val >> 32));
	my_put_be32(s, (uint32_t)(val & 0xffffffff));
}

static void my_put_amf_double(DATA *s, double d)
{
	my_put_byte(s, AMF_DATA_TYPE_NUMBER);
	my_put_be64(s, av_dbl2int(d));
}

static void my_put_flush_packet(DATA *pb)
{
#ifdef MY_DEBUG
	fwrite(pb->data,pb->nCurrentposite,1,fp);
	pb->nCurrentposite=0;
#else
	sender.SendData(pb->data,pb->nCurrentposite);
	pb->nCurrentposite=0;
#endif
}

static int my_flv_write_header(AVFormatContext *s)
{
//	ByteIOContext *pb = s->pb;
	
	FLVContext *flv = (FLVContext *)s->priv_data;
	AVCodecContext *audio_enc = NULL, *video_enc = NULL;
	int i;
	double framerate = 0.0;
	int metadata_size_pos, data_size;

	video_enc=s->streams[0]->codec;
	
	my_put_tag(pb,"FLV");
	my_put_byte(pb,1);
	my_put_byte(pb,1);
	my_put_be32(pb,9);
	my_put_be32(pb,0);

	/* write meta_tag */
	my_put_byte(pb, 18);         // tag type META
	my_put_be24(pb,159);          // size of data part (sum of all parts below)
	my_put_be24(pb, 0);          // time stamp
	my_put_be32(pb, 0);          // reserved

	/* now data of data_size size */	

	/* first event name as a string */
	my_put_byte(pb, AMF_DATA_TYPE_STRING);
	my_put_amf_string(pb, "onMetaData"); // 12 bytes

	/* mixed array (hash) with size and string/type/data tuples */
	my_put_byte(pb, AMF_DATA_TYPE_MIXEDARRAY);
	my_put_be32(pb, 5 + 2); // +2 for duration and file size

	my_put_amf_string(pb, "duration");
	my_put_amf_double(pb,0);

	if(video_enc){
		my_put_amf_string(pb, "width");
		my_put_amf_double(pb, 320);

		my_put_amf_string(pb, "height");
		my_put_amf_double(pb, 240);

		my_put_amf_string(pb, "videodatarate");
		my_put_amf_double(pb, 195.31);

		my_put_amf_string(pb, "framerate");
		my_put_amf_double(pb, 0);

		my_put_amf_string(pb, "videocodecid");
		my_put_amf_double(pb, 2);

		my_put_amf_string(pb, "filesize");
		my_put_amf_double(pb, 0); // delayed write
	}

	my_put_amf_string(pb, "");
	my_put_byte(pb, AMF_END_OF_OBJECT);
	
	my_put_be32(pb,170);
	

	return 0;
}

#define AV_PKT_FLAG_KEY   0x0001

static int my_flv_write_packet(AVFormatContext *s, AVPacket *pkt)
{
//	ByteIOContext *pb = s->pb;
	AVCodecContext *enc = s->streams[pkt->stream_index]->codec;
	FLVContext *flv = (FLVContext *)s->priv_data;
	static unsigned int ts=0;
	int size= pkt->size;
	uint8_t *data= NULL;
	int flags, flags_size;

	flags_size= 1;

	my_put_byte(pb, FLV_TAG_TYPE_VIDEO);

	flags = 2;

	flags |= pkt->flags & AV_PKT_FLAG_KEY ? FLV_FRAME_KEY : FLV_FRAME_INTER;
	 

//	ts = pkt->dts + flv->delay; // add delay to force positive dts
	ts=GetTickCount()-lTime;
//	ts += 10;


	my_put_be24(pb,size + flags_size);
	my_put_be24(pb,ts);
	my_put_byte(pb,(ts >> 24) & 0x7F); // timestamps are 32bits _signed_
	my_put_be24(pb,flv->reserved);
	my_put_byte(pb,flags);
	

	my_put_buffer(pb, data ? data : pkt->data, size);

	my_put_be32(pb,size+flags_size+11); // previous tag size
//	flv->duration = FFMAX(flv->duration, pkt->pts + flv->delay + pkt->duration);

	my_put_flush_packet(pb);
	

	av_free(data);

	return 0;
}

#define INT64_MIN       (-0x7fffffffffffffffLL - 1)

int64_t my_rescale_rnd(int64_t a, int64_t b, int64_t c, enum AVRounding rnd){
	int64_t r=0;

	if(a<0 && a != INT64_MIN) return -my_rescale_rnd(-a, b, c, (enum AVRounding)(rnd ^ ((rnd>>1)&1)));

	if(rnd==AV_ROUND_NEAR_INF) r= c/2;
	else if(rnd&1)             r= c-1;

	if(b<=INT_MAX && c<=INT_MAX){
		if(a<=INT_MAX)
			return (a * b + r)/c;
		else
			return a/c*b + (a%c*b + r)/c;
	}else{
		uint64_t a0= a&0xFFFFFFFF;
		uint64_t a1= a>>32;
		uint64_t b0= b&0xFFFFFFFF;
		uint64_t b1= b>>32;
		uint64_t t1= a0*b1 + a1*b0;
		uint64_t t1a= t1<<32;
		int i;

		a0 = a0*b0 + t1a;
		a1 = a1*b1 + (t1>>32) + (a0<t1a);
		a0 += r;
		a1 += a0<r;

		for(i=63; i>=0; i--){
			//            int o= a1 & 0x8000000000000000ULL;
			a1+= a1 + ((a0>>i)&1);
			t1+=t1;
			if(/*o || */c <= a1){
				a1 -= c;
				t1++;
			}
		}
		return t1;
	}
}

void my_free_packet(AVPacket *pkt)
{
	if (pkt) {
		if (pkt->destruct) pkt->destruct(pkt);
		pkt->data = NULL; pkt->size = 0;
	}
}

int64_t my_rescale_q(int64_t a, AVRational bq, AVRational cq){
	int64_t b= bq.num * (int64_t)cq.den;
	int64_t c= cq.num * (int64_t)bq.den;
	return my_rescale_rnd(a, b, c, AV_ROUND_NEAR_INF);
}




static void write_video_frame(AVFormatContext *oc, AVStream *st,uint8_t* pRGB32)
{
    int out_size, ret;
    AVCodecContext *c;
    static struct SwsContext *img_convert_ctx;

    c = st->codec;

	if(pRGB32)
	{
		fill_yuv_image(picture, frame_count, c->width, c->height,pRGB32);
	}


    
    /* encode the image */
    out_size = avcodec_encode_video(c, video_outbuf, video_outbuf_size, picture);
    /* if zero size, it means the image was buffered */
    if (out_size > 0) {
        AVPacket pkt;
        av_init_packet(&pkt);

        if (c->coded_frame->pts != AV_NOPTS_VALUE)
			pkt.pts= my_rescale_q(c->coded_frame->pts, c->time_base, st->time_base);

        if(c->coded_frame->key_frame)
            pkt.flags |= PKT_FLAG_KEY;
        pkt.stream_index= st->index;
        pkt.data= video_outbuf;
        pkt.size= out_size;

		ret = my_flv_write_packet(oc, &pkt);
    } else {
        ret = 0;
    }
   
    frame_count++;
}

static void close_video(AVFormatContext *oc, AVStream *st)
{
    avcodec_close(st->codec);
    av_free(picture->data[0]);
    av_free(picture);
    if (tmp_picture) {
        av_free(tmp_picture->data[0]);
        av_free(tmp_picture);
    }
    av_free(video_outbuf);
}


int main(int argc,char *argv[])
{
	const char filename[]={"test.flv"};
	AVOutputFormat *fmt;
	AVFormatContext *oc;
	uint8_t * pTemp;
	AVStream *video_st;
	double video_pts;
	int i;

	if(!pb)
	{
		pb=new DATA;
	}	

#ifdef MY_DEBUG
	if(!fp)
	{
		fp=fopen("video.flv","wb");
	}
#endif

	pb->data=(uint8_t*)new uint8_t[200000];
	pb->nCurrentposite=0;
	
	
	CDevice *pDevice = CDevice::init();

	av_register_all();

	fmt = guess_format(NULL, filename, NULL);
	if (!fmt) {
		fprintf(stderr, "Could not find suitable output format\n");
		exit(1);
	}

	oc = av_alloc_format_context();
	if (!oc) {
		fprintf(stderr, "Memory error\n");
		exit(1);
	}
	oc->oformat = fmt;
	snprintf(oc->filename, sizeof(oc->filename), "%s", filename);


	video_st = NULL;
    if (fmt->video_codec != CODEC_ID_NONE) {
        video_st = add_video_stream(oc, fmt->video_codec);
    }
    if (av_set_parameters(oc, NULL) < 0) {
        fprintf(stderr, "Invalid output format parameters\n");
        exit(1);
    }

    dump_format(oc, 0, filename, 1);

    if (video_st)
        open_video(oc, video_st);

	lTime=GetTickCount();

//	av_write_header(oc);
	my_flv_write_header(oc);

	__try
	{	
		while(true)
		{
			ImageRGB _ImageRGB={0};
			_ImageRGB = pDevice->getLastImage();			
			if (_ImageRGB.pTexRGBData)
			{
				if (video_st)
					video_pts = (double)video_st->pts.val * video_st->time_base.num / video_st->time_base.den;
				else
					video_pts = 0.0;

				pTemp=new uint8_t[_ImageRGB.width*_ImageRGB.height*4];
				memcpy(pTemp,_ImageRGB.pTexRGBData,_ImageRGB.width*_ImageRGB.height*4);
				write_video_frame(oc, video_st,pTemp);
				delete []pTemp;
				pTemp=NULL;
			}			
		}
	}
	__finally
	{
		av_write_trailer(oc);

		/* close each codec */
		if (video_st)
			close_video(oc, video_st);

		/* free the streams */
		for(i = 0; i < oc->nb_streams; i++) {
			av_freep(&oc->streams[i]->codec);
			av_freep(&oc->streams[i]);
		}

		if (!(fmt->flags & AVFMT_NOFILE)) {
			url_fclose(oc->pb);
		}

		/* free the stream */
		av_free(oc);

		CDevice::uninit();

		if(pb->data)
		{
			delete [] pb->data;
			pb->data=NULL;
			pb->nCurrentposite=0;
		}

		if(pb)
		{
			delete pb;
			pb=NULL;
		}

#ifdef MY_DEBUG
		if(fp)
		{
			fclose(fp);
			fp=NULL;
		}
#endif
 	}
	
	return 0;
}