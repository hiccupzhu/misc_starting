#include "UDPSend.h"


#pragma comment(lib,"WS2_32")

CUDPSend::CUDPSend(void)
{
	int error=WSAStartup(MAKEWORD(2,2),&m_wsaData);

	if(error!=0)
	{
		return;
	}

	if(LOBYTE(m_wsaData.wVersion)!=2 || HIBYTE(m_wsaData.wVersion)!=2)
	{
		WSACleanup();
		return;
	}

	m_socket=socket(AF_INET,SOCK_DGRAM,0);

	m_sockSend.sin_addr.S_un.S_addr=inet_addr("192.168.5.13");
	m_sockSend.sin_port=htons(8888);
	m_sockSend.sin_family=AF_INET;
}

CUDPSend::~CUDPSend(void)
{
	closesocket(m_socket);

	WSACleanup();
}

int CUDPSend::SendData(BYTE *buff,int nLen)
{
	int lenword=0;
	lenword=sendto(m_socket,(char*)buff,nLen+1,0,(sockaddr *)&m_sockSend,sizeof(sockaddr));
	return lenword;
}
