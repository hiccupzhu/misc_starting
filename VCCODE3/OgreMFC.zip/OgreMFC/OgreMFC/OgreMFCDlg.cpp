
// OgreMFCDlg.cpp : ʵ���ļ�
//
#include "stdafx.h"

#include "OgreMFC.h"
#include "OgreMFCDlg.h"

#include <ogre/OgreRoot.h>
#include <ogre/OgreConfigFile.h>
#include <ogre/ExampleFrameListener.h>
#include <ogre/OgreCommon.h>
#include <ogre/OgreRenderSystem.h>
#include <OIS/OISInputManager.h>
#include <OIS/OISPrereqs.h>

#include "MyFrameListener.h"
#include <OgreTagPoint.h>

#define OGRE_DEBUG_MEMORY_MANAGER 1


Ogre::Root *pRoot=NULL;
Ogre::Camera* pCamera=NULL;
Ogre::SceneManager* pSceneMgr=NULL;
MyFrameListener* pMyFrameListener=NULL;
Ogre::RenderWindow* pWindow=NULL;
OIS::InputManager* pInputManager=NULL;
Ogre::SceneNode* pNode=NULL;


COgreMFCDlg::COgreMFCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COgreMFCDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void COgreMFCDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SHOW, m_show);
}

BEGIN_MESSAGE_MAP(COgreMFCDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON1, &COgreMFCDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_SKELETON, &COgreMFCDlg::OnBnClickedSkeleton)
	ON_BN_CLICKED(IDC_CAMERAIN, &COgreMFCDlg::OnBnClickedCamerain)
	ON_BN_CLICKED(IDC_CAMERAOUT, &COgreMFCDlg::OnBnClickedCameraout)
END_MESSAGE_MAP()

HWND g_hwnd=NULL;

LRESULT CALLBACK MouseProc(          int nCode,
						   WPARAM wParam,
						   LPARAM lParam
						   )
{
	HRESULT hr=NULL;
	static bool flag=false;
	std::stringstream strs;
	std::string str;
	if(nCode==HC_ACTION)
	{
		if(g_hwnd)
		{
			static CPoint point;
			static CPoint pointlast;			
			GetCursorPos(&point);
			CRect rc;
			GetWindowRect(g_hwnd,&rc);

			if(rc.PtInRect(point))
			{
				switch(wParam)
				{
				case WM_LBUTTONDOWN:	
					flag=true;
					break;
				case WM_LBUTTONUP:
					flag=false;
					break;
				default:
					break;
				}
				if(flag)
				{					
					::ScreenToClient(g_hwnd,&point);
					int nx=point.x-pointlast.x;
					int ny=point.y-pointlast.y;
					strs<<"x="<<point.x<<":y="<<point.y<<":nx="<<nx;
					strs>>str;
					str += "\n";
					TRACE(str.c_str());
					const int distance=1;
					if(nx>distance)
					{
						((Node*)pNode)->yaw((Ogre::Radian)(0.05));
					}
					else if(nx<-distance)
					{
						((Node*)pNode)->yaw((Ogre::Radian)(-0.05));
					}

					if(ny>distance)
					{
						((Node*)pNode)->pitch((Ogre::Radian)(0.05));
					}
					else if(ny<-distance)
					{
						((Node*)pNode)->pitch((Ogre::Radian)(-0.05));
					}
					pointlast=point;
				}
			}
		}
	}
	return hr;
}


BOOL COgreMFCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();	
	GetDlgItem(IDC_CAMERASTEP)->SetWindowText("0.05");

	pRoot=new Root("plugins_d.cfg","ogre.cfg","ogre.log");

	Ogre::ConfigFile cf;
	cf.load("resources_d.cfg");
	Ogre::ConfigFile::SectionIterator seci=cf.getSectionIterator();

	Ogre::String secName, typeName, archName;
	while (seci.hasMoreElements())
	{
		secName = seci.peekNextKey();
		Ogre::ConfigFile::SettingsMultiMap *settings = seci.getNext();
		Ogre::ConfigFile::SettingsMultiMap::iterator i;
		for (i = settings->begin(); i != settings->end(); ++i)
		{
			typeName = i->first;
			archName = i->second;
			Ogre::ResourceGroupManager::getSingleton().addResourceLocation(archName, typeName, secName);
		}
	}

	bool carrayOn=false;
	carrayOn=pRoot->showConfigDialog();
	if(carrayOn)
	{
		pRoot->initialise( false );

		Ogre::NameValuePairList miscParams; 
		miscParams["externalWindowHandle"] = Ogre::StringConverter::toString( (uint32)m_show.m_hWnd );
		g_hwnd=m_show.m_hWnd;
		CRect rc;
		m_show.GetWindowRect(&rc);
		 
		pWindow=pRoot->createRenderWindow("123",rc.Width() , rc.Height(), false, &miscParams );

		pSceneMgr=pRoot->createSceneManager(ST_GENERIC,"sceneMgr1");
		pCamera=pSceneMgr->createCamera("camera1");
		pCamera->setPosition(Ogre::Vector3(0,0,10));
		pCamera->lookAt(Ogre::Vector3(0,0,-1));
		pCamera->setNearClipDistance(1);

		Ogre::Viewport* vp = pWindow->addViewport(pCamera);
		vp->setBackgroundColour(Ogre::ColourValue(0,0,0));
		pCamera->setAspectRatio(Ogre::Real(vp->getActualWidth()) / Ogre::Real(vp->getActualHeight()));

		Ogre::TextureManager::getSingleton().setDefaultNumMipmaps(5);
		Ogre::ResourceGroupManager::getSingleton().initialiseAllResourceGroups();

		pSceneMgr->setAmbientLight(Ogre::ColourValue(0.5, 0.5, 0.5));
		Ogre::Light* l = pSceneMgr->createLight("MainLight");
		l->setPosition(20,80,50);

		std::string str="E:\\CODE1\\SDK\\Project\\output\\Debug\\plugins\\media\\skinsShape.mesh";
		int n=str.find_last_of("\\");
		std::string str1=str.substr(n+1);
		std::string str2=str.substr(0,n);
		Ogre::ResourceGroupManager::getSingleton().addResourceLocation(archName, typeName, "");
		Ogre::Entity *ent = pSceneMgr->createEntity("skinsShape",str1);
		ent->setMaterialName("Examples/EnvMappedRustySteel");
		Ogre::Node* pSceneNode=(Ogre::SceneNode*)pSceneMgr->getRootSceneNode()->createChild("scene1");
		pNode=(Ogre::SceneNode*)pSceneNode->createChild("node1",Ogre::Vector3(-2,0,0));
		pNode->attachObject(ent);

		Ogre::Entity *e = pSceneMgr->createEntity("wwww","skinsShape.mesh");
		pNode=(Ogre::SceneNode*)pSceneNode->createChild("node2",Ogre::Vector3(1,0,0));
		pNode->attachObject(e);


		SetWindowsHookEx(WH_MOUSE,MouseProc,NULL,GetCurrentThreadId());

	}

	


// 	pMyFrameListener=new MyFrameListener(pCamera,pWindow);
// 	pRoot->addFrameListener(pMyFrameListener);
// 	pFrameListener= new ExampleFrameListener(pWindow, pCamera);
// 	pRoot->addFrameListener(pFrameListener);
// 	ParamList pl;
// 
// 	unsigned long h = (unsigned long)m_hWnd;
// 	pl.insert(std::make_pair(std::string("WINDOW"), StringConverter::toString(h)));
// 
// 	pl.insert(std::make_pair(std::string("w32_mouse"), std::string("DISCL_NONEXCLUSIVE")));
// 	pl.insert(std::make_pair(std::string("w32_mouse"), std::string("DISCL_FOREGROUND")));
// 	pl.insert(std::make_pair(std::string("w32_keyboard"), std::string("DISCL_NONEXCLUSIVE")));
// 	pl.insert(std::make_pair(std::string("w32_keyboard"), std::string("DISCL_FOREGROUND")));
// 	pInputManager = InputManager::createInputSystem( pl );


/*	pRoot->startRendering();*/

	
	SetTimer(1,40,NULL);

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void COgreMFCDlg::OnPaint()
{
// 	pRoot->_fireFrameStarted();
// 	pWindow->update();
// 	pRoot->_fireFrameEnded();

	pRoot->renderOneFrame();
//	pNode->yaw((Ogre::Radian)0.005f);

}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR COgreMFCDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


BOOL COgreMFCDlg::DestroyWindow()
{
	delete pMyFrameListener;
	delete pRoot;

	return CDialog::DestroyWindow();
}

void COgreMFCDlg::OnTimer(UINT_PTR nIDEvent)
{
	OnPaint();
}

BOOL COgreMFCDlg::PreTranslateMessage(MSG* pMsg)
{
	static float xf=0.00f;
	static float yf=0.00f;
	static float zf=0.00f;
	float step = 0.05f;
	if(pMsg->message == WM_KEYDOWN)
	{
		switch(pMsg->wParam)
		{
		case VK_UP:
			zf += step;
			break;
		case VK_DOWN:
			zf -= step;
			break;
		case VK_LEFT:
			xf -= step;
			break;
		case VK_RIGHT:
			xf += step;			
			break;
		default:
			break;
		}
		((Node*)pNode)->setPosition(Ogre::Vector3(xf,yf,zf));
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void COgreMFCDlg::OnBnClickedButton1()
{
	static bool bFalg=true;
	Ogre::SceneNode* node1=(Ogre::SceneNode*)pSceneMgr->getRootSceneNode()->getChild("node1");
	
	if(bFalg)
	{
		node1->setVisible(false);
		bFalg=false;
	}
	else
	{
		node1->setVisible(true);
		bFalg=true;
	}
}



void COgreMFCDlg::OnBnClickedSkeleton()
{
	static std::vector<Ogre::Entity*> vlist;
	std::vector<Ogre::Vector3> vNodePosition;

	Ogre::SceneNode* sceneNode = (Ogre::SceneNode*)pSceneMgr->getRootSceneNode()->getChild("scene1");
	Ogre::SceneNode* mainNode=(Ogre::SceneNode*)((Node*)sceneNode)->getChild("node1");
	
	Ogre::Entity* mainEntity = (Ogre::Entity*)mainNode->getAttachedObject(0);
	
	Ogre::SkeletonInstance* mSkel = mainEntity->getSkeleton();

	//Number of the skeleton's bones
	int count = mSkel->getNumBones();

	//Create Ankle
	for(int i=0; i<count; i++)
	{
		Ogre::Bone* currBone = mSkel->getBone(i);
		///////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////
		Ogre::Vector3 position= ((Node*)currBone)->getPosition();
		vNodePosition.push_back(position);
	}

	Ogre::SceneNode* pSkeletonNode=(Ogre::SceneNode*)((Node*)sceneNode)->createChild("skeleton1",Ogre::Vector3(3,0,0));	
	for (int i=0;i<count;i++)
	{		
		Ogre::String sphereName="PK_"+Ogre::StringConverter::toString(i);
		Ogre::Entity* e1 = pSceneMgr->createEntity(sphereName, "Sphere.mesh");
		Ogre::Node* ppn=((Node*)pSkeletonNode)->createChild(sphereName,vNodePosition[i]);
		ppn->setScale(0.0002,0.0002,0.0002);
		((Ogre::SceneNode*)ppn)->attachObject(e1);
		
	}
}

void COgreMFCDlg::OnBnClickedCamerain()
{
	CString str;
	GetDlgItem(IDC_CAMERASTEP)->GetWindowText(str);
	double dd=atof(str.GetString());
	Ogre::Vector3 cameraPosition=pCamera->getPosition();
	cameraPosition.z -= dd;
	pCamera->setPosition(cameraPosition);
}

void COgreMFCDlg::OnBnClickedCameraout()
{
	CString str;
	GetDlgItem(IDC_CAMERASTEP)->GetWindowText(str);
	double dd=atof(str.GetString());
	Ogre::Vector3 cameraPosition=pCamera->getPosition();
	cameraPosition.z += dd;
	pCamera->setPosition(cameraPosition);
}
