#include <ogre\OgreFrameListener.h>
#include <ogre\OgreWindowEventUtilities.h>
#include <OIS\OISKeyboard.h>
#include <OIS\OISMouse.h>
#include <ogre\OgreCamera.h>
#include <ogre\OgreRenderWindow.h>
#include <OIS\OISInputManager.h>
#pragma once

using namespace Ogre;

class MyFrameListener: public FrameListener,public WindowEventListener,
	public OIS::KeyListener,public OIS::MouseListener
{
public:
	MyFrameListener(Camera* camera,RenderWindow* render_win);
	~MyFrameListener(void);

protected:
	bool frameStarted(const FrameEvent& evt);

	bool frameEnded(const FrameEvent& evt);

	virtual void windowResized(RenderWindow* rw);

	virtual void windowClosed(RenderWindow* rw);

	bool keyPressed(const OIS::KeyEvent &arg);

	bool keyReleased(const OIS::KeyEvent &arg);

	bool mouseMoved(const OIS::MouseEvent &arg);

	bool mousePressed(const OIS::MouseEvent &arg, OIS::MouseButtonID id);

	bool mouseReleased(const OIS::MouseEvent &arg, OIS::MouseButtonID id);
private:
	Camera *                        m_camera;
	RenderWindow *                  m_render_win;

	bool                            m_is_shutdown;

	OIS::InputManager*              m_input_mgr;
	OIS::Mouse*                     m_mouse;
	OIS::Keyboard*                  m_keyboard;

};
