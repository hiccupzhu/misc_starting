#include "StdAfx.h"
#include "MyFrameListener.h"


MyFrameListener::MyFrameListener(Camera * camera,RenderWindow * render_win):
m_camera(camera),
m_render_win(render_win),
m_is_shutdown(false)
{
	OIS::ParamList pl;
	size_t windowHnd = 0;
	std::ostringstream windowHndStr;

	render_win->getCustomAttribute("WINDOW", &windowHnd);
	windowHndStr << windowHnd;
	pl.insert(std::make_pair(std::string("WINDOW"), windowHndStr.str()));

	m_input_mgr = OIS::InputManager::createInputSystem(pl);

	m_keyboard = static_cast<OIS::Keyboard*>(m_input_mgr->createInputObject( OIS::OISKeyboard, true ));
	m_mouse = static_cast<OIS::Mouse*>(m_input_mgr->createInputObject( OIS::OISMouse, true ));

	m_keyboard->setEventCallback(this);
	m_mouse->setEventCallback(this);

	/// ���Լ�ע���windows event list��
	WindowEventUtilities::addWindowEventListener(render_win, this);

	windowResized(m_render_win);

}

MyFrameListener::~MyFrameListener()
{
	WindowEventUtilities::removeWindowEventListener(m_render_win, this);
	windowClosed(m_render_win);
}

bool MyFrameListener::frameStarted(const FrameEvent& evt)
{
//	m_mouse->capture();
	m_keyboard->capture();

	return true;
}

bool MyFrameListener::frameEnded(const FrameEvent& evt)
{
	if (m_is_shutdown)
		return false;

	return true;
}

void MyFrameListener::windowResized(RenderWindow* rw)
{
	unsigned int width, height, depth;
	int left, top;
	rw->getMetrics(width, height, depth, left, top);

	const OIS::MouseState &ms = m_mouse->getMouseState();
	ms.width = width;
	ms.height = height;
}

void MyFrameListener::windowClosed(RenderWindow* rw)
{
	if( rw == m_render_win )
	{
		if( m_input_mgr )
		{
			m_input_mgr->destroyInputObject(m_mouse);
			m_input_mgr->destroyInputObject(m_keyboard);

			OIS::InputManager::destroyInputSystem(m_input_mgr);
			m_input_mgr = NULL;
		}
	}
}

bool MyFrameListener::keyPressed(const OIS::KeyEvent &arg)
{
	if (arg.key == OIS::KC_ESCAPE)
		m_is_shutdown = true;

	return true;
}

bool MyFrameListener::keyReleased(const OIS::KeyEvent &arg)
{
	return true;
}

bool MyFrameListener::mouseMoved(const OIS::MouseEvent &arg)
{
	return true;
}

bool MyFrameListener::mousePressed(const OIS::MouseEvent &arg, OIS::MouseButtonID id)
{
	return true;
}

bool MyFrameListener::mouseReleased(const OIS::MouseEvent &arg, OIS::MouseButtonID id)
{
	return true;
}

